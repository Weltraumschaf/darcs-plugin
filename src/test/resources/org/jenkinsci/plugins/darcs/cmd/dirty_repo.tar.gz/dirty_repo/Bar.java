
package de.weltraumschaf.test;

public class Bar {

    private final String value;
    
    public Bar(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
    
    @Override
    public String toString() {
        return value;
    }

}