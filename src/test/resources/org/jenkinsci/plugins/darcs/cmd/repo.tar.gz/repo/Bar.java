
class Bar {

    public static String makeBar() {
        return "BAR";
    }

}