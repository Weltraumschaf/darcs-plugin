
public class Foo {

    private String foo;

    public String getFoo() {
        return foo;
    }

    public void setFoo(final String f) {
        foo = f;
    }

}