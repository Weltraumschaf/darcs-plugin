/*
 * This comment was added later on.
 */

package de.weltraumschaf.test;

public class Foo {

    private final String value;

    public Foo(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return value;
    }
    
}