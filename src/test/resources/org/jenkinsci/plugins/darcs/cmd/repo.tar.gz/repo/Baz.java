
class Baz {

    public String foo;
    public String bar;
    public String baz;

}