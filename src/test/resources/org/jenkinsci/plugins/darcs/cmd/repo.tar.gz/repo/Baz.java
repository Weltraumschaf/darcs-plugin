
package de.weltraumschaf.test;

public class Baz {

    private final String value;

    public Baz(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return value;
    }
    
}